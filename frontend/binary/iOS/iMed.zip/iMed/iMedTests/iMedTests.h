//
//  iMedTests.h
//  iMedTests
//
//  Created by Riccardo Loti on 09/10/12.
//  Copyright (c) 2012 MyMed. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface iMedTests : SenTestCase

@end

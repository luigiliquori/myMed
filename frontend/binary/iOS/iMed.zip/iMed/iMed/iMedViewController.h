//
//  iMedViewController.h
//  iMed
//
//  Created by Riccardo Loti on 09/10/12.
//  Copyright (c) 2012 MyMed. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iMedViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

//
//  iMedAppDelegate.h
//  iMed
//
//  Created by Riccardo Loti on 09/10/12.
//  Copyright (c) 2012 MyMed. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iMedAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

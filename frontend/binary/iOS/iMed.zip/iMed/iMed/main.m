//
//  main.m
//  iMed
//
//  Created by Riccardo Loti on 09/10/12.
//  Copyright (c) 2012 MyMed. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "iMedAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([iMedAppDelegate class]));
  }
}

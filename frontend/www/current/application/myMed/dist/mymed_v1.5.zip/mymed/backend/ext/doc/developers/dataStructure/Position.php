<!-- Position -->
<div id="position" class="componenent">
	<span class="columnFamilyName">Position:</span>
	<table class="columnFamily">
		<tbody>
			<tr>
				<th>Key</th>
				<th>Value</th>
			</tr>
			<tr>
				<td class="positionID">POSITION_ID</td>
				<td>
					<table>
						<tbody>
							<tr>
								<th>Key</th>
								<th>Value</th>
							</tr>
							<tr>
								<td>latitude</td>
								<td class="type">Double</td>
							</tr>
							<tr>
								<td>longitude</td>
								<td class="type">Double</td>
							</tr>
							<tr>
								<td>city</td>
								<td class="type">String</td>
							</tr>
							<tr>
								<td>zipCode</td>
								<td class="type">String</td>
							</tr>
							<tr>
								<td>country</td>
								<td class="type">String</td>
							</tr>
							<tr>
								<td>formattedAddress</td>
								<td class="type">String</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</div>

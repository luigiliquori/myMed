/*
 * Copyright 2012 INRIA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.mymed.controller.core.exception;

/**
 * Use to return an explicit server Error 500 to the frontend
 * 
 * @author lvanni
 * 
 */
public class InternalBackEndException extends AbstractMymedException {

    /* --------------------------------------------------------- */
    /* Attributes */
    /* --------------------------------------------------------- */
    private static final long serialVersionUID = 1L;

    /* --------------------------------------------------------- */
    /* Constructors */
    /* --------------------------------------------------------- */
    public InternalBackEndException(final String message) {
        super(500, message);
    }
    
    public InternalBackEndException(final String message, Object ... args) {
        this(String.format(message, args));
    }
    
    public InternalBackEndException(final Exception e) {
        super(e, e.getMessage());
    }

    public InternalBackEndException(final Exception e, final String message) {
        super(e, message);
    }
}

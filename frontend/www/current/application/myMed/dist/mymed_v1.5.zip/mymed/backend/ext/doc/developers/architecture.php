<div id="architecture" align="center">
	<img alt="architecture" src="img/Node.png" width="1000px;">
</div>

<?php 
/**
 *
 * Represent a requet handler
 * @author lvanni
 *
 */
interface IRequestHandler {

	/**
	 * handle HTTP Request
	 */
	
	public function handleRequest();

}
?>
<div id="raterList" class="componenent">
	<!-- Transaction -->
	<span class="columnFamilyName">RaterList:</span>
	<table class="columnFamily">
	  <tr>
	    <th>Key</th>
	    <th>Value</th>
	  </tr>
	  <tr>
	    <td class="">USER_ID_ID+SERVICE_ID</td>
	    <td>
		  <div>
			  	<span class="columnFamilyName">Rater:</span>
			   	<table class="columnFamily">
				  <tr>
				    <th>Key</th>
				    <th>Value</th>
				  </tr>
				  <tr>
				    <td>USER_ID</td>
				    <td>
						<table>
						  <tr>
						    <th>Key</th>
						    <th>Value</th>
						  </tr>
						  <tr>
						    <td>value</td>
						    <td class="type">Double</td>
						  </tr>
						  <tr>
						    <td>lastRating</td>
						    <td class="type">Date</td>
						  </tr>
						</table>
				    </td>
				  </tr>
				</table>
			</div>
	    </td>
	  </tr>
	</table>
</div>
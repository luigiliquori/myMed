<div id="rest" align="center">

	<?php 
	include('restAPI/AuthenticationRequestHandler.php'); 
	include('restAPI/SessionRequestHandler.php');
	include('restAPI/ProfileRequestHandler.php');
	include('restAPI/FindRequestHandler.php');
	include('restAPI/PublishRequestHandler.php');
	include('restAPI/SubscribeRequestHandler.php');
	include('restAPI/ReputationRequestHandler.php');
	include('restAPI/InteractionRequestHandler.php');
	include('restAPI/PositionRequestHandler.php');
	include('restAPI/POIRequestHandler.php');
	?>

</div>

<!-- InteractionList -->
<div id="interactionList" class="componenent">
	<span class="columnFamilyName">InteractionList:</span>
	<table class="columnFamily">
		<tbody>
			<tr>
				<th>Key</th>
				<th>Value</th>
			</tr>
			<tr>
				<td class="interactionListID">INTERACTION_LIST_ID</td>
				<td>
					<div>
						<span class="columnFamilyName">Interaction:</span>
						<table class="columnFamily">
							<tbody>
								<tr>
									<th>Key</th>
									<th>Value</th>
								</tr>
								<tr>
									<td class="interactionID">INTERACTION_ID</td>
									<td>
										<table>
											<tbody>
												<tr>
													<th>Key</th>
													<th>Value</th>
												</tr>
												<tr>
													<td>name</td>
													<td class="type">String</td>
												</tr>
												<tr>
													<td>id</td>
													<td class="interactionID">INTERACTION_ID</td>
												</tr>
											</tbody>
										</table></td>
								</tr>
							</tbody>
						</table>
					</div></td>
			</tr>
		</tbody>
	</table>
</div>

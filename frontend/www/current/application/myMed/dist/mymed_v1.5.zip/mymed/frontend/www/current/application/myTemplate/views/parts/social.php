
<span style="position: absolute;top:0;right:5px;opacity: 0.8;">
	<a class="social" style="background-position: -33px 0px;" href="..." title="myMed on Google+"></a>
	<a class="social" style="background-position: 0px 0px;" href="..." title="myMed on Twitter"></a>
	<a class="social" style="background-position: -66px 0px;" href="..." title="myMed on Facebook"></a>
</span>

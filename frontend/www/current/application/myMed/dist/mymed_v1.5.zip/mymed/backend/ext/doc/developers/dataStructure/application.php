<div id="application" class="componenent">
	<!-- Applciation -->
	<span class="columnFamilyName">Application: <span class="type">(ColumnFamily)</span></span>
   	<table class="columnFamily">
	  <tr>
	    <th>Key <span class="type">(Key)</span></th>
	    <th>Value</th>
	  </tr>
	  <tr>
	    <td class="applicationID">APPLICATION_ID</td>
	    <td>
			<table>
				  <tr>
				    <th>Key <span class="type">(ColumnName)</span></th>
				    <th>Value <span class="type">(ColumnValue)</span></th>
				  </tr>
				  <tr>
				    <td>model</td>
				    <td class="applicationModelID">APPLICATION_MODEL_ID</td>
				  </tr>
				  <tr>
				    <td>view</td>
				    <td class="applicationViewID">APPLICATION_VIEW_ID</td>
				  </tr>
				  <tr>
				    <td>controller</td>
				    <td class="applciationControllerID">APPLICATION_CONTROLLER_ID</td>
				  </tr>
			</table>
	    </td>
	  </tr>
	</table>
</div>
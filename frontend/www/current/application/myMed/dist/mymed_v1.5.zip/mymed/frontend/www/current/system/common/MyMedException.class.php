<?php

/**
 * Custom Exceptions catched by the main controller and shown to the user.
 */
abstract class MyMedException extends Exception {
}

?>
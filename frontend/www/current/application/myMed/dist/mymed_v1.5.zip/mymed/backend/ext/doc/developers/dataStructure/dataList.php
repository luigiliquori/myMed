<!-- DataList -->
<div id="applicationGroup" class="componenent">
	<span class="columnFamilyName">DataList:</span>
	<table class="columnFamily">
		<tbody>
			<tr>
				<th>Key</th>
				<th>Value</th>
			</tr>
			<tr>
				<td class="dataListID">APPLICATION_ID+SUB_PREDICATE_ID+USER_ID</td>
				<td>
					<div>
						<span class="columnFamilyName">Data:</span>
						<table class="columnFamily">
							<tbody>
								<tr>
									<th>Key</th>
									<th>Value</th>
								</tr>
								<tr>
									<td class="dataID">DATA_ID</td>
									<td>
										<table>
											<tbody>
												<tr>
													<th>Key</th>
													<th>Value</th>
												</tr>
												<tr>
													<td>key</td>
													<td class="type">DATA_ID</td>
												</tr>
												<tr>
													<td>value</td>
													<td class="type">byte[]</td>
												</tr>
												<tr>
													<td>ontology</td>
													<td class="ontologyID">ONTOLOGY_ID</td>
												</tr>
											</tbody>
										</table></td>
								</tr>
							</tbody>
						</table>
					</div></td>
			</tr>
		</tbody>
	</table>
</div>

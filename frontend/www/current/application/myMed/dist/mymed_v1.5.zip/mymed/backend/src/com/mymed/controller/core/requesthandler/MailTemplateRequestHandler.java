package com.mymed.controller.core.requesthandler;

/** API to manage the mail templates */
public class MailTemplateRequestHandler {
    
}

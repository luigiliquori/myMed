<? 
// Call the login / register page and display the "register" tab
$TAB = "register";
include("LoginView.php");
?>
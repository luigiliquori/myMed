<!-- AUTHENTICATION -->
<div id="authentication" class="componenent">
	<span class="columnFamilyName">Authentication:</span>
	<table class="columnFamily">
		<tbody>
			<tr>
				<th>Key</th>
				<th>Value</th>
			</tr>
			<tr>
				<td class="loginID">AUTHENTICATION_ID</td>
				<td>
					<table>
						<tbody>
							<tr>
								<th>Key</th>
								<th>Value</th>
							</tr>
							<tr>
								<td>login</td>
								<td class="loginID">AUTHENTICATION_ID</td>
							</tr>
							<tr>
								<td>user</td>
								<td class="userID">USER_ID</td>
							</tr>
							<tr>
								<td>password</td>
								<td class="type">sha512(string)</td>
							</tr>
						</tbody>
					</table></td>
			</tr>
		</tbody>
	</table>
</div>

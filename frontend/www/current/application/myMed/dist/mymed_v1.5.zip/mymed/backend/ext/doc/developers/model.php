<div id="model" align="center">

		<!-- HOME -->
		<?php include('dataStructure/index.php'); ?>

</div>

<!-- OntologyList -->
<div id="applicationGroup" class="componenent">
	<span class="columnFamilyName">OntologyList:</span>
	<table class="columnFamily">
		<tbody>
			<tr>
				<th>Key</th>
				<th>Value</th>
			</tr>
			<tr>
				<td class="ontologyListID">ONTOLOGY_LIST_ID</td>
				<td>
					<div>
						<span class="columnFamilyName">Ontology:</span>
						<table class="columnFamily">
							<tbody>
								<tr>
									<th>Key</th>
									<th>Value</th>
								</tr>
								<tr>
									<td class="ontologyID">ONTOLOGY_ID</td>
									<td>
										<table>
											<tbody>
												<tr>
													<th>Key</th>
													<th>Value</th>
												</tr>
												<tr>
													<td>name</td>
													<td class="type">String</td>
												</tr>
												<tr>
													<td>ontology</td>
													<td class="ontologyID">ONTOLOGY_ID</td>
												</tr>
											</tbody>
										</table></td>
								</tr>
							</tbody>
						</table>
					</div></td>
			</tr>
		</tbody>
	</table>
</div>

<div id="footer">

	<div style="position:relative; text-align: left; top:10px;">
	 	<a href="#"><b>Francais</b></a> |
	 	<a href="#" style="color: gray;">English</a> | 
	 	<a href="#" style="color: gray;">Italiano</a>
 	</div>
 	
 	<div style="position:relative; top:20px; height: 1px; background-color: #b0c0e1;"></div>
 	
 	<div style="position:relative; top:35px;">"Ensemble par-delà les frontières"</div>
 	
 	<!-- LOGOs  -->
 	<table style="position:relative; top:40px;">
	  <tr>
	    <td style="padding: 5px;"><img alt="" src="img/logos/alcotra" style="width: 100px;" /></td>
	    <td style="padding: 5px;"><img alt="" src="img/logos/europe" style="width: 50px;" /></td>
	    <td style="padding: 5px;"><img alt="" src="img/logos/cg06" style="width: 100px;" /></td>
	 	<td style="padding: 5px;"><img alt="" src="img/logos/regione" style="width: 100px;" /></td>
	 	<td style="padding: 5px;"><img alt="" src="img/logos/PACA" style="width: 100px;" /></td>
	 	<td style="padding: 5px;"><img alt="" src="img/logos/pref" style="width: 70px;" /></td>
	 	<td style="padding: 5px;"><img alt="" src="img/logos/inria" style="width: 100px;" /></td>
	  </tr>
	</table>
</div>
<div id="dataStructure">
	<?php include('applicationList.php'); ?><br />
	
	<?php include('applicationView.php'); ?><br />
	<?php include('applicationController.php'); ?><br />
	<?php include('applicationModel.php'); ?><br />
	<?php include('dataList.php'); ?><br />

	<?php include('ontologyList.php'); ?><br />
	<?php include('ontologyType.php'); ?><br />
	
	<?php include('user.php'); ?><br />
	<?php include('userList.php'); ?><br />
	<?php include('session.php'); ?><br />
	<?php include('authentication.php'); ?><br />
	
	<?php include('interactionList.php'); ?><br />
	<?php include('interaction.php'); ?><br />
	
	<hr>
	
	<?php include('reputation.php'); ?><br />
</div>

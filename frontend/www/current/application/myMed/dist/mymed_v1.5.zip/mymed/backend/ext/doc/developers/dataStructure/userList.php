<!-- Buddy -->
<div id="buddy" class="componenent">
	<span class="columnFamilyName">UserList:</span>
	<table class="columnFamily">
		<tbody>
			<tr>
				<th>Key</th>
				<th>Value</th>
			</tr>
			<tr>
				<td class="userListID">USER_LIST_ID</td>
				<td>
					<div>
						<span class="columnFamilyName">List:</span>
						<table class="columnFamily">
							<tbody>
								<tr>
									<th>Key</th>
									<th>Value</th>
								</tr>
								<tr>
									<td>USER_ID</td>
									<td>
										<table>
											<tbody>
												<tr>
													<th>Key</th>
													<th>Value</th>
												</tr>
												<tr>
													<td>name</td>
													<td class="type">String</td>
												</tr>
												<tr>
													<td>user</td>
													<td class="userID">USER_ID</td>
												</tr>
											</tbody>
										</table></td>
								</tr>
							</tbody>
						</table>
					</div></td>
			</tr>
		</tbody>
	</table>
</div>

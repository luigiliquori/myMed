<!-- 	<div  style="position: relative; top:50px; color: black;"> -->
<!-- 	<h4>myMed - INTERREG IV - Alcotra</h4> -->
<!-- 		<img alt="Alcotra" src="/system/img/logos/alcotra" style="width: 100px;" />
	<img alt="Europe" src="/system/img/logos/europe" style="width: 50px;" />
	<img alt="Conseil Général 06" src="/system/img/logos/cg06" style="width: 100px;" />
	<img alt="Regine Piemonte" src="/system/img/logos/regione" style="width: 100px;" />
	<img alt="Région PACA" src="/system/img/logos/PACA" style="width: 100px;" />
	<img alt="Prefecture 06" src="/system/img/logos/pref" style="width: 70px;" />
	<img alt="Inria" src="/system/img/logos/inria.jpg" style="width: 100px;" /> -->
<!-- 	<p>"Ensemble par-delà les frontières"</p> -->
<!-- </div> -->


<h4 class="logo">myMed - INTERREG IV - Alcotra</h4>

<div>
	<img alt="Alcotra" src="/system/img/logos/alcotra" />
	<img alt="Conseil Général 06" src="/system/img/logos/cg06" />
	<img alt="Regine Piemonte" src="/system/img/logos/regione"/>
	<img alt="Europe" src="/system/img/logos/europe" />
	<img alt="Région PACA" src="/system/img/logos/PACA" />
	<img alt="Prefecture 06" src="/system/img/logos/pref" />
	<img alt="Inria" src="/system/img/logos/inria.png" />
</div>
<?php

header("Location: server.php");

?>
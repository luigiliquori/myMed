<?php

/** 
 *  Human readable exception due to internal error
 */
class InternalError extends MyMedException {}

?>
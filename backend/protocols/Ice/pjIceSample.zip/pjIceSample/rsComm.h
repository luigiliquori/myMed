/* 
 * File:   rsComm.h
 * Author: user
 *
 * Created on April 13, 2011, 8:33 AM
 */

#ifndef RSCOMM_H
#define	RSCOMM_H

#ifdef	__cplusplus
extern "C" {
#endif


int rsInit(char* ip, char* port);
int rsRegisterSelf(char* userName);
void rsAskUsers();
int readRsCommand(char* buf, int bufSize);
void rsConnReq(char* user, char* myContactInfo);
void rsConnReply(char* connId, char* myContactInfo);

#ifdef	__cplusplus
}
#endif

#endif	/* RSCOMM_H */

